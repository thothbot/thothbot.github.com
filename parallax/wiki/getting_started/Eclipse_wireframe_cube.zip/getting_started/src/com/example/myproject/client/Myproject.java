/*
 * Copyright 2012 Alex Usachev, thothbot@gmail.com
 * 
 * This file is part of Squirrel project.
 * 
 * Squirrel is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the 
 * Free Software Foundation, either version 3 of the License, or (at your 
 * option) any later version.
 * 
 * Squirrel is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
 * for more details.
 * 
 * You should have received a copy of the GNU General Public License along with 
 * Squirrel. If not, see http://www.gnu.org/licenses/.
 */

package com.example.myproject.client;

import thothbot.parallax.core.client.RenderingPanel;
import thothbot.parallax.core.client.RenderingReadyEvent;
import thothbot.parallax.core.client.RenderingReadyHandler;
import thothbot.parallax.core.client.RenderingScene;
import thothbot.parallax.core.client.RenderingPanel.RenderPanelAttributes;
import thothbot.parallax.core.shared.cameras.PerspectiveCamera;
import thothbot.parallax.core.shared.core.Color3f;
import thothbot.parallax.core.shared.geometries.Cube;
import thothbot.parallax.core.shared.materials.MeshBasicMaterial;
import thothbot.parallax.core.shared.materials.MeshLambertMaterial;
import thothbot.parallax.core.shared.objects.Mesh;
import thothbot.parallax.core.shared.utils.ImageUtils;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootLayoutPanel;

public class Myproject implements EntryPoint {

	class MyScene extends RenderingScene {

		private Mesh mesh;
		
		@Override
		protected void loadCamera() {
			// Loads default camera for the Renderer
			setCamera(
					new PerspectiveCamera(
							70, // field of view
							getRenderer().getCanvas().getAspectRation(), // aspect ratio 
							1, // near
							1000 // far 
					));
		}

		@Override
		protected void onStop() {
			// Called immediately after the rendering is stopped.
		}

		@Override
		protected void onStart() {
			// Called before the rendering starts. The Scene should be
			// defined here.
			getCamera().getPosition().setZ(400);
			getScene().addChild(getCamera());

			Cube geometry = new Cube( 200, 200, 200 );

			MeshBasicMaterial.MeshBasicMaterialOptions options = new MeshBasicMaterial.MeshBasicMaterialOptions();
			options.color = new Color3f(0xFF0000);
			options.wireframe = true;
			MeshBasicMaterial material = new MeshBasicMaterial(options);

			this.mesh = new Mesh(geometry, material);
			getScene().addChild(mesh);
		}
		
		@Override
		protected void onUpdate(double duration) {
			this.mesh.getRotation().setX(this.mesh.getRotation().getX() + 0.005f);
			this.mesh.getRotation().setY(this.mesh.getRotation().getY() + 0.01f);

			super.onUpdate(duration);
		}
	}
	
	@Override
	public void onModuleLoad() {
		RenderPanelAttributes att = new RenderPanelAttributes();
		att.clearColor         = 0x111111; // Background color
		att.clearAlpha         = 1.0f;     // Background color transparency
		
		final RenderingPanel renderingPanel = new RenderingPanel(att);
		renderingPanel.setRenderingScene(new MyScene());
		renderingPanel.addAnimationReadyEventHandler(new RenderingReadyHandler() {
			
			@Override
			public void onAnimationReady(RenderingReadyEvent event) {
				renderingPanel.getRenderingScene().stop();
			}
		});
		// TODO Auto-generated method stub
		RootLayoutPanel.get().add(renderingPanel);
	}
}
